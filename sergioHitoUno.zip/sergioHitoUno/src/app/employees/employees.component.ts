import { Component, OnInit } from '@angular/core';
import { log } from 'util';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {

  Employees = [
    {
      id: "0",
      name: "Miguel",
      surname: "Malagon"
    },
    {
      id: "1",
      name: "Bruno",
      surname: "Baruno"
    },
    {
      id: "2",
      name: "Marta",
      surname: "Madrastra"
    }
  ]

  deleteEmployee(id: string) {
    const index = this.Employees.map(e => e.id).indexOf(id);
    this.Employees.splice(index, 1)
  }

  OnInput(id, value) {
    let obj = this.Employees.find(f => f.id == id);
    if(obj)
      obj.name = value;
  }

  OnInputTwo(id, value) {
    let obj = this.Employees.find(f => f.id == id);
    if(obj)
      obj.surname = value;
  }

  onSubmit(a, b) {
    if(a != "" && b != "")
      this.Employees.push({id: Math.floor(Math.random() * 101).toString(), name: a, surname: b})
  }

  constructor() { }

  ngOnInit(): void {
  }

}
