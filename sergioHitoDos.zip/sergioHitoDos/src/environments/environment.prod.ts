export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAmEBKjVj6BK9vUi_0mrguylYVARdUKsQE",
    authDomain: "sergiohito2.firebaseapp.com",
    databaseURL: "https://sergiohito2.firebaseio.com",
    projectId: "sergiohito2",
    storageBucket: "sergiohito2.appspot.com",
    messagingSenderId: "935745999855",
    appId: "1:935745999855:web:8847b422676bf9be189c1a",
    measurementId: "G-LB2YCMJ45G"
  }
};