import { Injectable } from '@angular/core';
import { Empleado } from '../shared/Empleado';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';

@Injectable({
  providedIn: 'root'
})

export class EmpleadoService
{
  employeeListRef: AngularFireList<any>;
  employeeRef: AngularFireObject<any>;

  constructor(private db: AngularFireDatabase) { }

  // Create
  createEmployee(apt: Empleado) {
    return this.employeeListRef.push({
      name: apt.name,
      email: apt.email,
      mobile: apt.mobile,
      birthday: apt.birthday
    })
  }

  // Get Single
  getEmployee(id: string) {
    this.employeeRef = this.db.object('/empleado/' + id);
    return this.employeeRef;
  }

  // Get List
  getEmployeeList() {
    this.employeeListRef = this.db.list('/empleado');
    return this.employeeListRef;
  }

  // Update
  updateEmployee(id, apt: Empleado) {
    return this.employeeRef.update({
      name: apt.name,
      email: apt.email,
      mobile: apt.mobile,
      birthday: apt.birthday
    })
  }

  // Delete
  deleteEmployee(id: string) {
    this.employeeRef = this.db.object('/empleado/' + id);
    this.employeeRef.remove();
  }
}
