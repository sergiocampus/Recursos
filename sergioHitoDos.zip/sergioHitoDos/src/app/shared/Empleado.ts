export class Empleado {
    $key: string;
    name: string;
    email: string
    mobile: number;
    birthday: Date;
}