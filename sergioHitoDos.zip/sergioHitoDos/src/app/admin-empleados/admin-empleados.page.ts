import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";
import { FormGroup, FormBuilder } from "@angular/forms";
import { EmpleadoService } from './../shared/empleado.service';

@Component({
  selector: 'app-admin-empleados',
  templateUrl: './admin-empleados.page.html',
  styleUrls: ['./admin-empleados.page.scss'],
})

export class AdminEmpleadosPage implements OnInit
{
  updateEmployeeForm: FormGroup;
  id: any;

  constructor(
    private aptService: EmpleadoService,
    private actRoute: ActivatedRoute,
    private router: Router,
    public fb: FormBuilder
  ) {
    this.id = this.actRoute.snapshot.paramMap.get('id');
    this.aptService.getEmployee(this.id).valueChanges().subscribe(res => {
      this.updateEmployeeForm.setValue(res);
    });
  }

  ngOnInit() {
    this.updateEmployeeForm = this.fb.group({
      name: [''],
      email: [''],
      mobile: [''],
      birthday: ['']
    })
    console.log(this.updateEmployeeForm.value)
  }

  updateForm() {
    this.aptService.updateEmployee(this.id, this.updateEmployeeForm.value)
      .then(() => {
        this.router.navigate(['/home']);
      })
      .catch(error => console.log(error));
  }
}