import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { AdminEmpleadosPageRoutingModule } from './admin-empleados-routing.module';

import { AdminEmpleadosPage } from './admin-empleados.page';

@NgModule({
  imports: [
    CommonModule,
    IonicModule,
    AdminEmpleadosPageRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [AdminEmpleadosPage]
})
export class AdminEmpleadosPageModule {}
