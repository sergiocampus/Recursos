import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder } from "@angular/forms";
import { EmpleadoService } from './../shared/empleado.service';

@Component({
  selector: 'app-add-empleado',
  templateUrl: './add-empleado.page.html',
  styleUrls: ['./add-empleado.page.scss'],
})

export class AddEmpleadoPage implements OnInit
{
  employeeForm: FormGroup;

  constructor(
    private aptService: EmpleadoService,
    private router: Router,
    public fb: FormBuilder
  ) { }

  ngOnInit() {
    this.employeeForm = this.fb.group({
      name: [''],
      email: [''],
      mobile: [''],
      birthday: ['']
    })
  }

  formSubmit() {
    if (!this.employeeForm.valid) {
      return false;
    } else {
      this.aptService.createEmployee(this.employeeForm.value).then(res => {
        console.log(res)
        this.employeeForm.reset();
        this.router.navigate(['/home']);
      })
        .catch(error => console.log(error));
    }
  }
}
