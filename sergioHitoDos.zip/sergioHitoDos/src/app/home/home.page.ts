import { Component, OnInit } from '@angular/core';
import { Empleado } from '../shared/Empleado';
import { EmpleadoService } from './../shared/empleado.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})

export class HomePage implements OnInit {
  Employees = [];

  constructor(
    private aptService: EmpleadoService
  ) { }

  ngOnInit() {
    this.fetchEmployees();
    let employeeRes = this.aptService.getEmployeeList();
    employeeRes.snapshotChanges().subscribe(res => {
      this.Employees = [];
      res.forEach(item => {
        let a = item.payload.toJSON();
        a['$key'] = item.key;
        this.Employees.push(a as Empleado);
      })
    })
  }

  fetchEmployees() {
    this.aptService.getEmployeeList().valueChanges().subscribe(res => {
      console.log(res)
    })
  }

  deleteEmployee(id) {
    console.log(id)
    if (window.confirm('Estas seguro?')) {
      this.aptService.deleteEmployee(id)
    }
  }
}
