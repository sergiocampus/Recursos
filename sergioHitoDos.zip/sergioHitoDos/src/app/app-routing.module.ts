import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)},
  {
    path: 'add-empleado',
    loadChildren: () => import('./add-empleado/add-empleado.module').then( m => m.AddEmpleadoPageModule)
  },
  {
    path: 'admin-empleados/:id',
    loadChildren: () => import('./admin-empleados/admin-empleados.module').then( m => m.AdminEmpleadosPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
