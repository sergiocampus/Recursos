from django.contrib import admin
from hito.models import Producto

admin.site.register(Producto)