from django.db import models

class Producto(models.Model):
    titulo = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(upload_to='images/')
    date = models.DateTimeField(auto_now_add=True)
    precio = models.FloatField()