from django.urls import path
from hito import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('catalogo/', views.catalogo, name='catalogo'),
    path('producto/<int:pk>/', views.pagProducto, name='pagProducto'),
]