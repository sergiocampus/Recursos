from django.db import migrations, models
import django.utils.timezone


class Migration(migrations.Migration):

    dependencies = [
        ('hito', '0006_auto_20191215_0308'),
    ]

    operations = [
        migrations.AddField(
            model_name='producto',
            name='date',
            field=models.DateTimeField(auto_now_add=True, default=django.utils.timezone.now),
            preserve_default=False,
        ),
        migrations.AddField(
            model_name='producto',
            name='precio',
            field=models.FloatField(default=0),
            preserve_default=False,
        ),
    ]

