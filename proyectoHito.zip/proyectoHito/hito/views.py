from django.views.generic import ListView
from django.shortcuts import render
from hito.models import Producto

def inicio(request):
    datos = Producto.objects.order_by('date')[0:3]
    context = {
        'datos': datos
    }
    return render(request, 'index.html', context)

def catalogo(request):
    datos = Producto.objects.all()
    context = {
        'datos': datos
    }
    return render(request, 'catalogo.html', context)

def pagProducto(request, pk):
    datos = Producto.objects.get(pk = pk)
    context = {
        'datos': datos
    }
    return render(request, 'producto.html', context)