package application;
	
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXMLLoader;


public class Main extends Application
{
	@Override
	public void start(Stage rootStage) throws Exception
	{
		//Hecho por Sergio Nebreda Andrés
		
		//Escenas
		FXMLLoader appLoader = new FXMLLoader(getClass().getResource("App.fxml"));
    	BorderPane appPane = (BorderPane) appLoader.load();
    	Scene app = new Scene(appPane, 700, 400);
    	app.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
    	
    	FXMLLoader secondLoader = new FXMLLoader(getClass().getResource("Second.fxml"));
    	AnchorPane secondPane = (AnchorPane) secondLoader.load();
    	Scene second = new Scene(secondPane, 200, 200);
    	second.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
    	
    	//Enviar escena a controlador
    	AppController appController = (AppController) appLoader.getController();
    	appController.setStageAndNextScene(rootStage, second);
    	
    	SecondController secondController = (SecondController) secondLoader.getController();
    	secondController.setStageAndNextScene(rootStage, app);
    	
    	//Inicializacion
    	appPane.requestFocus();
    	
    	rootStage.setTitle("Ventana");
    	rootStage.setResizable(false);
    	rootStage.setScene(app);
    	rootStage.sizeToScene();
    	rootStage.show();
	}
	
	public static void main(String[] args)
	{
		launch(args);
	}
}
