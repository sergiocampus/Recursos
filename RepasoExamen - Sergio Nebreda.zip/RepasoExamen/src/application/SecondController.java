package application;

import javafx.scene.Scene;
import javafx.stage.Stage;

public class SecondController
{
	//Administrar escenas
	private Stage rootStage;
	private Scene nextScene;

    public void setStageAndNextScene(Stage stage, Scene scene)
    {
    	rootStage = stage;
        nextScene = scene;
    }
    
    public void volver()
    {
    	rootStage.setScene(nextScene);
    }
}
