package application;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class AppController
{
	//Administrar escenas
	private Stage rootStage;
	private Scene nextScene;

    public void setStageAndNextScene(Stage stage, Scene scene)
    {
    	rootStage = stage;
        nextScene = scene;
    }
    
    //FXML
    @FXML
    private TextField txtUserId;
    
    @FXML
    private PasswordField txtPassId;
    
    @FXML
    private TextField txtId;
    
    @FXML
    private Label txtLbId;
    
    @FXML
   	public void login()
   	{
    	String user = "admin";
    	String password = "123456";
    	
    	if(txtUserId.getText().equals(user) && txtPassId.getText().equals(password))
    	{
    		rootStage.setScene(nextScene);
    		txtUserId.setText("");
    		txtPassId.setText("");
    	}
    	else 
    	{
    		Alert alert = new Alert(AlertType.INFORMATION);
        	alert.setTitle("Información");
        	alert.setHeaderText(null);
        	alert.setContentText("Email y/o contraseña incorrectos");
        	alert.showAndWait();
    	}
   	}
    
    @FXML
   	public void setTxt()
   	{
    	txtLbId.setText(txtId.getText());
   	}
}
